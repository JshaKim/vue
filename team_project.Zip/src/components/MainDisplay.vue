<script>
/*
  메인 페이지 게시판 컴포넌트(default 상태)
*/
</script>

<template>
  <div class="main_container">
    <div class="main_display">
      <h3>등록된 연락처 없음</h3>
    </div>
  </div>
</template>

<style scoped>
.main_display {
  color: #808080;
  text-align: center;
}
.main_container {
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 160px;
  background-color: #b9b9b9;
  color: white;
  border-radius: 10px;
  margin-top: 1%;
}
</style>
