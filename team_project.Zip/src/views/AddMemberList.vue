<script setup>
import Second_Header from "@/components/Second_Header.vue";
import AddMember from "@/components/AddMember.vue";
</script>

<template>
  <Second_Header />
  <AddMember />
</template>

<style scoped></style>
