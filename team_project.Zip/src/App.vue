<script setup>
import HomeView from "./views/HomeView.vue";
import AddMemberList from "./views/AddMemberList.vue";
</script>

<template>
  <!--<HomeView />-->
  <AddMemberList />

</template>

<style scoped></style>
