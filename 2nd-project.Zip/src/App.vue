<script setup>
import { RouterView } from 'vue-router'

</script>

<template>

<main>
<RouterView/>
</main>

</template>

<style scoped>

</style>
