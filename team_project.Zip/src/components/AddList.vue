<script setup>
/*
  메인 페이지 연락처 탭 추가 컴포넌트_최종 결과
*/
</script>

<template>
  <div class="contact-form">
    <div class="memberInfo">

    </div>
  </div>
</template>

<style scoped></style>
