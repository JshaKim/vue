<script setup>
import Header from "../components/Header.vue";
import MainDisplay from "../components/MainDisplay.vue";
import AddList from "../components/AddList.vue";

</script>

<template>
    <Header />
    <MainDisplay />
    <AddList />
</template>

<style scoped>
</style>
