<template>
  <header>
    <div class="header">
      <h1>내 연락처</h1>
    </div>
  </header>
</template>

<style scoped>

.header {
  background-color: #00bfa5;
  color: white;
  text-align: center;
  padding: 20px;
  border-bottom-left-radius: 10px;
  border-bottom-right-radius: 10px;
}

</style>

